<?php 

$conn = mysqli_connect('localhost','root','','tutorial_daerah');
?>